HOW TO PLAY - Key Bindings

Press R to go to Escape menu instead of Esc button
A - Strafe left/Backward
D - Strafe Right/Forward
Space - Jump
Mouse - Aim
Mouse Left Click - Shoot